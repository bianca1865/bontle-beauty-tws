const express = require("express");
const router = express.Router();
const validateService = require("../middleware/validateService");
const {
  getAllServices,
  getServiceById,
  createService,
  updateService,
  deleteService,
} = require("../controllers/services.controller");

router.get("/", getAllServices);
router.get("/:id", getServiceById);
router.post("/", validateService, createService);
router.put("/:id", validateService, updateService);
router.delete("/:id", deleteService);

module.exports = router;
