function validateService(req, res, next) {
  const { name, durationMinutes, price } = req.body;
  const errors = [];

  if (!name || typeof name !== "string" || !name.trim()) {
    errors.push("name is required and must be a non-empty string");
  }

  if (
    durationMinutes === undefined ||
    !Number.isInteger(durationMinutes) ||
    durationMinutes <= 0
  ) {
    errors.push("durationMinutes is required and must be a positive integer");
  }

  if (price === undefined || isNaN(Number(price)) || Number(price) < 0) {
    errors.push("price is required and must be a non-negative number");
  }

  if (req.body.description !== undefined && typeof req.body.description !== "string") {
    errors.push("description must be a string if provided");
  }

  if (errors.length > 0) {
    return res.status(400).json({ errors });
  }

  next();
}

module.exports = validateService;
