const prisma = require("../lib/prisma");

// GET /api/services
async function getAllServices(req, res) {
  try {
    const includeInactive = req.query.includeInactive === "true";
    const services = await prisma.service.findMany({
      where: includeInactive ? {} : { isActive: true },
      orderBy: { name: "asc" },
    });
    res.json(services);
  } catch (err) {
    console.error("getAllServices error:", err);
    res.status(500).json({ error: "Failed to fetch services" });
  }
}

// GET /api/services/:id
async function getServiceById(req, res) {
  try {
    const service = await prisma.service.findUnique({
      where: { id: req.params.id },
    });

    if (!service) {
      return res.status(404).json({ error: "Service not found" });
    }

    res.json(service);
  } catch (err) {
    console.error("getServiceById error:", err);
    res.status(500).json({ error: "Failed to fetch service" });
  }
}

// POST /api/services
async function createService(req, res) {
  try {
    const { name, description, durationMinutes, price, isActive } = req.body;

    const service = await prisma.service.create({
      data: {
        name: name.trim(),
        description: description?.trim() || null,
        durationMinutes,
        price,
        isActive: isActive ?? true,
      },
    });

    res.status(201).json(service);
  } catch (err) {
    console.error("createService error:", err);
    res.status(500).json({ error: "Failed to create service" });
  }
}

// PUT /api/services/:id
async function updateService(req, res) {
  try {
    const { name, description, durationMinutes, price, isActive } = req.body;

    const service = await prisma.service.update({
      where: { id: req.params.id },
      data: {
        name: name.trim(),
        description: description?.trim() || null,
        durationMinutes,
        price,
        ...(isActive !== undefined ? { isActive } : {}),
      },
    });

    res.json(service);
  } catch (err) {
    if (err.code === "P2025") {
      return res.status(404).json({ error: "Service not found" });
    }
    console.error("updateService error:", err);
    res.status(500).json({ error: "Failed to update service" });
  }
}

// DELETE /api/services/:id — soft delete by default, ?hard=true to remove for real
async function deleteService(req, res) {
  try {
    const hardDelete = req.query.hard === "true";

    if (hardDelete) {
      await prisma.service.delete({ where: { id: req.params.id } });
      return res.status(204).send();
    }

    const service = await prisma.service.update({
      where: { id: req.params.id },
      data: { isActive: false },
    });

    res.json(service);
  } catch (err) {
    if (err.code === "P2025") {
      return res.status(404).json({ error: "Service not found" });
    }
    console.error("deleteService error:", err);
    res.status(500).json({ error: "Failed to delete service" });
  }
}

module.exports = {
  getAllServices,
  getServiceById,
  createService,
  updateService,
  deleteService,
};
